import UIKit
public extension UIColor {
  public struct Code {
    public static var pink: UIColor  { return UIColor(red: 0.99, green: 0.37, blue: 0.64, alpha: 1.00) }
    public static var white: UIColor { return UIColor(red: 0.87, green: 0.87, blue: 0.87, alpha: 1.00) }
    public static var background: UIColor  { return UIColor(red: 0.12, green: 0.12, blue: 0.14, alpha: 1.00) }
    public static var blue: UIColor { return UIColor(red: 0.31, green: 0.69, blue: 0.80, alpha: 1.00) }
    public static var yellow: UIColor { return UIColor(red: 0.85, green: 0.79, blue: 0.49, alpha: 1.00) }
    public static var red: UIColor { return UIColor(red: 1.00, green: 0.50, blue: 0.44, alpha: 1.00) }

  }
}
