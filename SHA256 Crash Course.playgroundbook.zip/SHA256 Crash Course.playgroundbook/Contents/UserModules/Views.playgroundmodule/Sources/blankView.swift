import PlaygroundSupport
import UIKit

public class BlankView: UIView {
	
	override public init(frame: CGRect) {
		super.init(frame: frame)
		self.backgroundColor = UIColor(red: 0.16, green: 0.16, blue: 0.19, alpha: 1.00)
	}
	
	required init?(coder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}

}


