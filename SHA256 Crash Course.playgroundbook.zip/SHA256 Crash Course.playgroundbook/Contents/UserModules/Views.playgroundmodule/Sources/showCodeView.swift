import PlaygroundSupport
import UIKit

public class ShowCodeView: UIView {
    var mainLabel: UILabel!
    var tupleArrray: [(String, UIColor)]?
    
    public init(frame: CGRect, code: [(String, UIColor)]) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(red: 0.16, green: 0.16, blue: 0.19, alpha: 1.00)
        setupViews()
        tupleArrray = code        
    }
    
    public override func didMoveToWindow() {
        let initialString = NSMutableAttributedString(string: "")
        guard let wordsArray = tupleArrray else {
            mainLabel.attributedText = NSAttributedString(string: "")
            return
        }
        DispatchQueue.global(qos: .background).async {
            sleep(1)

            for item in wordsArray {
                let myString = item.0
                let myAttribute  = [NSAttributedString.Key.foregroundColor: item.1]
                
                let sleepTime = myString.count > 30 ? UInt32(5000) : UInt32(100000)

                for letter in myString {
                    let myAttrLetter = NSAttributedString(string: String(describing: letter), attributes: myAttribute)
                    let currentAttrString = self.mainLabel.attributedText ?? NSAttributedString(string: "")
                    let currentMutableAttrString = NSMutableAttributedString(attributedString: currentAttrString)
                    currentMutableAttrString.append(myAttrLetter)
                    DispatchQueue.main.async {
                        self.mainLabel.attributedText = currentMutableAttrString
                    }
                    usleep(sleepTime)
                }
            }
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    var midStack: UIStackView = {
        let thisView = UIStackView()
        thisView.axis = .vertical
        thisView.distribution = .fill
        thisView.spacing = 5
        thisView.translatesAutoresizingMaskIntoConstraints = false
        return thisView
    }()

    func setupViews() {
        mainLabel = createALabel(lines: 0, size: 24.0)
        midStack.addArrangedSubview(mainLabel)
        self.addSubview(midStack)
        setupConstraints()
    }
    
    func createALabel(lines: Int, size: CGFloat) -> UILabel {
        let textLabel =  UILabel()
        textLabel.numberOfLines = lines
        textLabel.widthAnchor.constraint(equalToConstant:self.frame.width).isActive = true
        textLabel.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
        textLabel.adjustsFontSizeToFitWidth = true
        textLabel.font = UIFont.systemFont(ofSize: size, weight: UIFont.Weight.bold)
        textLabel.textAlignment = .left
        return textLabel
    }

    
    func setupConstraints() {
        midStack.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        midStack.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        
        midStack.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 80).isActive = true
        midStack.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -80).isActive = true
        
        midStack.topAnchor.constraint(equalTo: self.topAnchor, constant: 80).isActive = true
        midStack.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -80).isActive = true
        

    }

}
