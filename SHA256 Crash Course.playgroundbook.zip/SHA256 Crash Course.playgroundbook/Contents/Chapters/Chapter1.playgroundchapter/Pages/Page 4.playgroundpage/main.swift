//#-hidden-code
//Page 4
import UIKit
import PlaygroundSupport
//#-end-hidden-code

import CryptoKit
/*:
* Callout(Goal:):
To learn that a great hashing algorithm like SHA256 will be weak if the developer (You!) does not implement proper security.
## Let's try to crack a passcode!
* Callout(To Do:):
Again, enter a passcode
- Important: Passcode must be 4 characters (digits).
*/
var passcodeToHash: String = /*#-editable-code passcode*/"1234"/*#-end-editable-code*/
//#-hidden-code
func finished(everything: [(String, UIColor)], timeString: String?) {
    let myView = ShowCodeView(frame: .zero, code: everything)
    PlaygroundPage.current.liveView = myView
    
    //    if timeString == "0"
    guard let time = timeString else {
        PlaygroundPage.current.assessmentStatus = .pass(message: "### Welp, that did not take long. Now let's see how we can fix this!\n [**Tap here to better secure this passcode!.**](@next)")
        return
    }
    
    PlaygroundPage.current.assessmentStatus = .pass(message: "### Welp, that did not take long. Only \(time) seconds! Now let's see how we can fix this!\n [**Tap here to better secure this passcode!.**](@next)")
}
let thisView = ShowCodeLiveView(frame: .zero, initialMessage: "CRACKING!!")
PlaygroundPage.current.liveView = thisView
func showError(hints: [String], solution: String?) {
    DispatchQueue.main.async {
        thisView.mainLabel.text = "Error Cracking!\nCheck for a hint below!"
    }
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
//#-end-hidden-code
func crackPasscode() {
/*:
 - Note:
  These first few lines of code are identical to the last page.
*/
let yourPasscodeData = passcodeToHash.data(using: .utf8)

guard let yourUnwrappedData = yourPasscodeData else {
    return
}
//#-hidden-code

if passcodeToHash.count != 4 {
    let passcodeCount = passcodeToHash.count
    showError(hints: [" # Looks like your password is not 4 digits, it's \(passcodeCount).", "Make sure to use leading zeroes on your passcode if necessary!"], solution: nil)
    
    return
    
}
//#-end-hidden-code
let yourHashedPasscode = SHA256.hash(data: yourUnwrappedData)
let yourHashedPasscodeString = yourHashedPasscode.compactMap { String(format: "%02x", $0) }.joined()

//#-hidden-code
DispatchQueue.global(qos: .background).async {
    let start = CFAbsoluteTimeGetCurrent()
    //#-end-hidden-code
/*: # Let's try to decrypt your password!
 ## Suppose this playground were to have accidently leak the hashed passcode you created!!
 ### Would your passcode be safe? It was hashed, right?  RIGHT?!!
 # Let's try a for loop!
* Callout(To Do:):
 Set `maxPasscode` to the maximum passcode that you want to check.

 - Example:
    The for loop will iterate through every possible passcode from 0000 to the maxPasscode you set.\
    So, when maxPasscode is set to 4. Our for loop uses SHA256 to hash:\
    _0000, 0001, 0002, 0003, and 0004_\
    If your passcode was _0003_, the program would be successful, but not if it was _0006_.\
    You need to pick the right maxPasscode to enable your program to guess any hashed 4 digit passcode.
- - -
 - Important:
    This system asks for a four digit passcode.
*/
    let maxPasscode = /*#-editable-code maxPasscode */0/*#-end-editable-code*/
//#-hidden-code
    if maxPasscode == 0 {
        showError(hints: [" # Looks like you haven't changed the maxPasscode."], solution: "Set `9999` as the `maxPasscode` in order to check every passcode between 0-9999.")
        return
    }
//#-end-hidden-code
    for passcodeToCheck in 0 ... maxPasscode{
        
/*:
* Callout(What's going on here?):
The trick here is that we need to convert 1, 20, and 300 to 0001, 0020, and 0300.
\
This next line of code will do just that!
After, the rest is following the hashing steps from the previous page!
*/
        let checkPasscodeString = String(format: "%04d", passcodeToCheck)
        let checkPasscodeData = checkPasscodeString.data(using: .utf8)
        
        if let data = checkPasscodeData {
            let hashed = SHA256.hash(data: data)
            let hashedString = hashed.compactMap { String(format: "%02x", $0) }.joined()
            
            //#-hidden-code
            DispatchQueue.main.async {
                thisView.mainLabel.text = "Yep, this is live, your Mac sure is fast!! \nChecking Passcode: \(checkPasscodeString)\nHashed: \(hashedString)"
            }
            //#-end-hidden-code
/*:
* Callout(What's going on here?):
Here we simply check to see if the hash computed on this loop is equal to the hash from your password that was "leaked".
*/
            if hashedString == yourHashedPasscodeString {
                let correctPasscode = checkPasscodeString
                print("Correct Passcode: \(correctPasscode)")
                //#-hidden-code
                let elapsed = -1 * (start - CFAbsoluteTimeGetCurrent())
                let elapsedString = String(format: "%.4f", elapsed)
                let newCodeToSend: [(String, UIColor)] = [
                    ("Found Passcode: ", UIColor.Code.white),
                    (correctPasscode, UIColor.Code.pink),
                    ("\nElapsed Time: ", UIColor.Code.white),
                    (elapsedString, UIColor.Code.pink),
                    (" seconds", UIColor.Code.pink),
                ]
                DispatchQueue.main.async {
                    finished(everything: newCodeToSend, timeString: elapsedString)
                }
                //#-end-hidden-code
                break
            }
            //#-hidden-code
            else if (passcodeToCheck == maxPasscode) {
                showError(hints: [" # Your passcode was never found. Check you maxPasscode", " # maxPasscode should be greater than or equal to your passcode if you want the program to crack it!"], solution: "Set '9999' as the 'maxPasscode' in order to check every passcode between 0-9999")
                    
                return
                
            }
            //#-end-hidden-code
        }
    }
    //#-hidden-code
}
//#-end-hidden-code
}
crackPasscode()
