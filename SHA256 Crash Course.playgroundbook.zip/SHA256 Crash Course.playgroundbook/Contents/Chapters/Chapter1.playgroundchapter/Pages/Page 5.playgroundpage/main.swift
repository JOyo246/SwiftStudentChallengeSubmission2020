//#-hidden-code
//Page 5
//salting
import UIKit
import PlaygroundSupport
//#-end-hidden-code

import CryptoKit

/*:
# Hopefully you now understand why hashing alone is not enough!
# Remember: It's important that we invest in hacking! Not to do harm, but to ensure the data of everyone is secure!
### Now we will learn about the industry standard when it comes to using SHA256 well and storing user information.
# The first thing you need to know about is: 🧂

* Callout(Definition:):
    # salt
    1. Used to flavor and season food.
    2. (Cryptography) a salt is random data that is used as an additional input to a one-way function that hashes data, a password or passphrase.
### Don't be worried, I'll walk you through it!
- - -
* Callout(Goal:):
To learn how to properly use SHA256 by salting the passcode before hashing.
- - -
* Callout(To Do:):
Again, enter a passcode
- Important: Passcode must be 4 characters (digits).
*/
var passcodeToHash: String = /*#-editable-code passcode*/"1234"/*#-end-editable-code*/
//#-hidden-code
func finished(everything: [(String, UIColor)]) {
    let myView = ShowCodeView(frame: .zero, code: everything)
    PlaygroundPage.current.liveView = myView

    PlaygroundPage.current.assessmentStatus = .pass(message: "### Thanks for joining me to learn about cybersecurity, Apple CryptoKit, SHA256, and salting! I hope you learned something new today!")
}
let thisView = ShowCodeLiveView(frame: .zero, initialMessage: "Hashing!!")
PlaygroundPage.current.liveView = thisView
func showError(hints: [String], solution: String?) {
    DispatchQueue.main.async {
        thisView.mainLabel.text = "Error Salting!\nCheck for a hint below!"
    }
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
//#-end-hidden-code
func encyrptWithSalt() {
    
//#-hidden-code
    if passcodeToHash.count != 4 {
        let passcodeCount = passcodeToHash.count
        showError(hints: ["Looks like your password is not 4 digits, it's \(passcodeCount).", "Make sure to use leading zeroes on your passcode if necessary!"], solution: nil)
        
        return
        
    }
//#-end-hidden-code
/*:
# Formerly, you went straight into hashing. This time we will add a random string after your passcode.
- Note: This random string is your salt!
* Callout(What's going on here?):
This code generates a random unique string in Swift! Perfect!
- Experiment: 
Run this page multiple times to see that your hashed value will be different, even though your passcode remains the same.
*/
    let saltString = UUID().uuidString
    print(saltString)

/*: 
Now, we'll add the string after your passcode and seperate them with a comma!\
This is stored in the `saltedPasscode` variable.
*/
    let saltedPasscode = passcodeToHash + "," + saltString
    
/*:
* Callout(To Do:):
Here's the code from our lesson on hashing, all you have to do is replace `passcodeToHash` with the salted passcode.
*/
    let passcodeData = /*#-editable-code passcode*/passcodeToHash/*#-end-editable-code*/.data(using: .utf8)
//#-hidden-code

    let noSaltData = passcodeToHash.data(using: .utf8)

    guard let unwrappedNoSaltData = noSaltData else {
        return
    }
    let hashedNoSalt = SHA256.hash(data: unwrappedNoSaltData)
    
    let hashedNoSaltString = hashedNoSalt.compactMap { String(format: "%02x", $0) }.joined()

//#-end-hidden-code
       guard let unwrappedData = passcodeData else {
        return
    }
    //#-hidden-code
    if unwrappedData == noSaltData {
        showError(hints: [" # Looks like you haven't replaced passcodeToHash."], solution: "Replace `passcodeToHash` in this line of code `let passcodeData = passcodeToHash.data(using: .utf8)`with `saltedPasscode`")
        
        return
        
    } else if (unwrappedData.count < 8){
                
        showError(hints: [" # Hmmm... something wrong with your `passcodeData`"], solution: "Replace `passcodeToHash` in this line of code `let passcodeData = passcodeToHash.data(using: .utf8)` with `saltedPasscode`")
        
        return
    }
    //#-end-hidden-code
    let hashed = SHA256.hash(data: unwrappedData)
    let hashedString = hashed.compactMap { String(format: "%02x", $0) }.joined()
    //#-hidden-code
    let newCodeToSend: [(String, UIColor)] = [
        ("Original Passcode: ", UIColor.Code.white),
        (passcodeToHash, UIColor.Code.pink),
        ("\nSHA256 Hashed: ", UIColor.Code.white),
        (hashedNoSaltString, UIColor.Code.pink),
        ("\n\nOriginal Passcode + Salt: ", UIColor.Code.white),
        (saltedPasscode, UIColor.Code.yellow),
        ("\nSHA256 Hashed with Salt: ", UIColor.Code.white),
        (hashedString, UIColor.Code.yellow),
        ("\n\nYAY!\t", UIColor.Code.yellow),
        ("Your passcode is now secure!", UIColor.Code.blue)
    ]
    DispatchQueue.main.async {
        finished(everything: newCodeToSend)
    }
    //#-end-hidden-code
}
encyrptWithSalt()


