//#-hidden-code
//Page 3
import UIKit
import PlaygroundSupport

let thisView = ShowCodeLiveView(frame: .zero, initialMessage: "Hashing!!")

PlaygroundPage.current.liveView = thisView

//#-end-hidden-code
import CryptoKit
/*:
* Callout(Goal:):
To learn how to hash a passcode using SHA256 hashing with Apple's new CryptoKit framework.\
- - -
* Callout(To Do:):
Now, let's enter a passcode, let's keep it down to 4 digits, after we will hash it using Apple CryptoKit!
*/
var passcodeToHash = /*#-editable-code passcode*/"1234"/*#-end-editable-code*/
/*:
- Note: Quotes are there to make sure your code is 4 digits. For example, 0103 is really the same number as 103!\
Now we get the data from the passcode. This basically converts your passcode into some universal characters that all computers can read!
*/
let passcodeData = passcodeToHash.data(using: .utf8)
//: # All that's left here is to hash using SHA256!
//: # SHA256 is an algorithm created by the NSA which is commonly used to secure your data in many modern day applications!
//#-hidden-code
func showError(hints: [String], solution: String?) {
    DispatchQueue.main.async {
        thisView.mainLabel.text = "Error Hashing!\nCheck for a hint below!"
    }
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
func finished(hashed: String) {
    
    let codeToSend: [(String, UIColor)] = [
        ("let ", UIColor.Code.pink),
        ("passcodeToHash ", UIColor.Code.blue),
        ("= ", UIColor.Code.white),
        (passcodeToHash, UIColor.Code.red),
        ("\nlet ", UIColor.Code.pink),
        ("passcodeData ", UIColor.Code.blue),
        ("= passcodeToHash.data(using: .utf8)\n", UIColor.Code.white),
        ("guard let ", UIColor.Code.pink),
        ("unwrappedData = ourData ", UIColor.Code.white),
        ("else ", UIColor.Code.pink),
        ("{\n", UIColor.Code.white),
        ("\t return\n", UIColor.Code.pink),
        ("}\n", UIColor.Code.white),
       

        ("let ", UIColor.Code.pink),
        ("hashed = SHA256.hash(data: unwrappedData)\n", UIColor.Code.white),
        ("let ", UIColor.Code.pink),
        ("hashedString = hashed.compactMap { String(format: ", UIColor.Code.white),
        ("\"%02x\"", UIColor.Code.red),
        (", $0) }.joined()\n", UIColor.Code.white),
        ("}", UIColor.Code.white),
        ("\n...\n", UIColor.Code.white),
        ("Hashed Passcode: ", UIColor.Code.white),
        (hashed, UIColor.Code.pink)
        ]

    let myView = ShowCodeView(frame: .zero, code: codeToSend)

    PlaygroundPage.current.liveView = myView
    
    PlaygroundPage.current.assessmentStatus = .pass(message: "### Nice! Now let's see how safe this is!\n [**Tap here to try and crack your code!.**](@next) ")
    
}
//#-end-hidden-code
func hashPasscode(){
    
//#-hidden-code   
    if passcodeToHash.count != 4 {
        let passcodeCount = passcodeToHash.count
        showError(hints: [" # Looks like your password is not 4 digits, it's \(passcodeCount).", "Make sure to use leading zeroes on your passcode if necessary!"], solution: nil)
        return
        
    }
//#-end-hidden-code
/*:
* Callout(What's going on here?):
First we make sure that we have the data from your code.
*/
    guard let unwrappedData = passcodeData else {
        return
    }
    
/*:
* Callout(What's going on here?):
Apple CryptoKit will perform the hash in this one line of code!
*/        
    let hashed = SHA256.hash(data: unwrappedData)
    
/*:
* Callout(What's going on here?):
This line converts the response from the algorithm into one simple string for us to display!
*/        
    let hashedString = hashed.compactMap { String(format: "%02x", $0) }.joined()
    //#-hidden-code
    finished(hashed: hashedString)
    //#-end-hidden-code
}
hashPasscode()



