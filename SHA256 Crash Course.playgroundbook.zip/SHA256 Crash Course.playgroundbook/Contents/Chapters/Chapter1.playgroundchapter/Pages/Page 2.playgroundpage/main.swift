//#-hidden-code
//Page 2
import PlaygroundSupport
import UIKit
let myView = BlankView(frame: .zero)
PlaygroundPage.current.liveView = myView
//#-end-hidden-code
/*:
* Callout(To Do:):
First you'll need to import CryptoKit. You can do this by typing `import CryptoKit`
*/
//#-editable-code Type your code here!

//#-end-editable-code
//: Apple's new framework, Apple CryptoKit will give you the ability to quickly hash your data!
//#-hidden-code
func finished() {
    
    let myView = ShowCodeView(frame: .zero, code: [("import ", UIColor.Code.white), ("CryptoKit", UIColor.Code.pink)])

    PlaygroundPage.current.liveView = myView
    
    PlaygroundPage.current.assessmentStatus = .pass(message: "### Perfect! You've imported CryptoKit!\n [**Click here to start using it!**](@next)")
    
}

if (CryptoKit.SHA256.self != nil) {
    finished()
}
//#-end-hidden-code

