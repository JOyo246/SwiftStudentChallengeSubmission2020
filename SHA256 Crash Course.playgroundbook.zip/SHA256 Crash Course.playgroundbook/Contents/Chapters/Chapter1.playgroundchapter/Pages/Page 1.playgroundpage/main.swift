//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code

/*:
 # Hi there! Welcome to my plaground!

 ## I decided to make this playground after learning about the SHA256 algorithm in my Intro to Cybersecurity class in University.
In class we learned all about how SHA256 hashing works. After doing our third and final Programming Assignment for the class, implementing SHA256 in Python, I started to research how I could do the same in Swift.
- Note: Many people think this is encryption. This considered a hashing function. Encrpytion would be two ways.. like a lock and key.\
Hashing is one-way, so that is the term we will use throughout the playground.
 
 # Here is a playground with some basics of SHA256 using Apple CryptoKit in Swift.
 [Let's learn!](@next)

- Note: Here's the assignment given to us, with permission from my professor, Dr. Beth Wilson.
![Programming Assignment - Cybersecurity](cropping2.png)
 */
//#-hidden-code

PlaygroundPage.current.assessmentStatus = .pass(message: "### Ready to go? [**Click here to head to the playground!**](@next)")
//#-end-hidden-code
